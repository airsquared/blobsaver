blobsaver has two optional dependencies for reading information from connected devices:

  - libimobiledevice: https://github.com/libimobiledevice/libimobiledevice (for ECID and device information)
  - libirecovery: https://github.com/libimobiledevice/libirecovery (for reading apnonce)
