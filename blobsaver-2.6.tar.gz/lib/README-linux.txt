blobsaver has one required dependency and two optional.
Make sure to install these on your system before continuing.

Required:
  - libfragmentzip (https://github.com/tihmstar/libfragmentzip)

Optional (for reading information from connected devices):
  - libimobiledevice (https://github.com/libimobiledevice/libimobiledevice)
  - libirecovery (https://github.com/libimobiledevice/libirecovery)

If you do not install these optional dependencies, blobsaver's
"Read from device" feature will not work.